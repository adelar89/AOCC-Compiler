#!/bin/bash


#===----------------------------------------------------------------------===#
#==== Copyright (c) 2015 Advanced Micro Devices, Inc. All rights reserved.
#
# Developed by: Advanced Micro Devices, Inc.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# with the Software without restriction, including without limitation the
# rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
# sell copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# Redistributions of source code must retain the above copyright notice, this
# list of conditions and the following disclaimers.
#
# Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimers in the documentation
# and/or other materials provided with the distribution.
#
# Neither the names of Advanced Micro Devices, Inc., nor the names of its
# contributors may be used to endorse or promote products derived from this
# Software without specific prior written permission.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS WITH
# THE SOFTWARE.
#===----------------------------------------------------------------------===#

gCompilerUt=""
gCompilerPpUt=""
gInput=""

gGlibcVersion=2.17
gCurrentGlibcVersion=0.0

gFailCount=0
gFailTestStatus=""
gPassCount=0
gPassTestStatus=""

declare -a glibalm

glibalm=(libalm.so)
glibomp=(libomp.so)

gDynamicLibMissing=0

glibtinfo="libtinfo.so.5"
glibtinfoStr="libtinfo.so"

glibz="libz.so.1"
glibzStr="libz.so"

g_crt_file=(crt1.o crti.o crtn.o)
g_libc_and_m=(libc.so libm.so)

printTestStatusAndExit()
{
	if [[ $gFailTestStatus != "" ]];then
		retVal=1
		echo -e "\nFailing Checks:"
		echo -e $gFailTestStatus
		if [[ $gDynamicLibMissing -eq 1 ]];then
			echo -e "\tExternal libraries in above failing checks/warnings are suggested to get best scores with AOCC"
			echo -e "\tIf your SPEC CPU2017 config does not use above external libraries then please ignore above failing checks/warnings related to these libraries.\n"
		fi
	else
		retVal=0
		echo -e "\nCheck:PASSED"
	fi

	if [[ $gPassTestStatus != "" ]];then
		echo -e "Passing Checks:"
		echo -e $gPassTestStatus
	fi

	exit $retVal
}

Fail_libc_and_m()
{
        gFailCount=$((gFailCount+1))
        gFailTestStatus="${gFailTestStatus}\t$gFailCount)WARNING: Folder containing libc and libm Eg:libc.so and libm.so is not present in LIBRARY_PATH\n\tWithout this compilation will fail\n\tAppend LIBRARY_PATH with folder containing these files\n\n"
}

Pass_libc_and_m()
{
        gPassCount=$((gPassCount+1))
	gPassTestStatus="${gPassTestStatus}\t$gPassCount) Check for libc and libm passed\n"
}

Test_libc_and_m()
{
local flagPass=0;


        ldPathAll=$LIBRARY_PATH
        old_IFS=$IFS
        IFS=':';allFolders=$ldPathAll
        for folder in ${allFolders[@]};
        do
                if [[ -d "$folder" ]];then
                {
                        for fl in ${g_libc_and_m[@]};
                        do
                                if [[ (-e "${folder}/${fl}") ]];then
                                        flagPass=1
                                        break 2
                                fi
                        done
                }
                fi
        done
        IFS=$old_IFS

        if [[ $flagPass -eq 0 ]];then
                Fail_libc_and_m
        else
                Pass_libc_and_m
        fi
}

Fail_crt_file()
{
        gFailCount=$((gFailCount+1))
        gFailTestStatus="${gFailTestStatus}\t$gFailCount)WARNING: Folder containing crt files crt1.o, crti.o and crtn.o are not present in LIBRARY_PATH\n\tWithout this compilation will fail\n\tAppend folder containing these files to LIBRARY_PATH\n\n"
}

Pass_crt_file()
{
        gPassCount=$((gPassCount+1))
	gPassTestStatus="${gPassTestStatus}\t$gPassCount) Check for crt files crt1.o, crti.o and crtn.o passed\n"
}

Test_crt_file()
{
local flagPass=0;


        ldPathAll=$LIBRARY_PATH
        old_IFS=$IFS
        IFS=':';allFolders=$ldPathAll
        for folder in ${allFolders[@]};
        do
                if [[ -d "$folder" ]];then
                {
                        for fl in ${g_crt_file[@]};
                        do
                                if [[ (-e "${folder}/${fl}") ]];then
                                        flagPass=1
                                        break 2
                                fi
                        done
                }
                fi
        done
        IFS=$old_IFS

        if [[ $flagPass -eq 0 ]];then
                Fail_crt_file
        else
                Pass_crt_file
        fi
}

Fail_OpenMP()
{
	gFailCount=$((gFailCount+1))
	gFailTestStatus="${gFailTestStatus}\t$gFailCount)WARNING: OpenMP library is required in both LIBRARY_PATH and LD_LIBRARY_PATH\n\tWithout this compilation will fail for source code which uses OpenMP library\n\tMake sure that both LIBRARY_PATH and LD_LIBRARY_PATH have folder containing OpenMP library files\n\n"
}

Pass_OpenMP()
{
	l_loc=$1
	gPassCount=$((gPassCount+1))
	gPassTestStatus="${gPassTestStatus}\t$gPassCount) OpenMP library => $l_loc\n"
}

Test_OpenMP()
{
local flagPass_LD_lib_path=0;
local flagPass_lib_path=0;
local l_file=""


	ldPathAll=$LD_LIBRARY_PATH
	old_IFS=$IFS
	IFS=':';allFolders=$ldPathAll
	for folder in ${allFolders[@]}; 
	do 
		if [[ -d "$folder" ]];then
		{
			for lib in ${glibomp[@]}; 
			do
				if [[ (-e "${folder}/${lib}") ]];then
					l_file="${folder}/${lib}"
					flagPass_LD_lib_path=1
					break 2
				fi
			done
		}
		fi
	done
	IFS=$old_IFS

	ldPathAll=$LIBRARY_PATH
	old_IFS=$IFS
	IFS=':';allFolders=$ldPathAll
	for folder in ${allFolders[@]};
	do
		if [[ -d "$folder" ]];then
		{
			for lib in ${glibomp[@]};
			do
				if [[ (-e "${folder}/${lib}") ]];then
					flagPass_lib_path=1
					break 2
				fi
			done
		}
		fi
	done
	IFS=$old_IFS

	if [[ ($flagPass_lib_path -eq 0) || ($flagPass_LD_lib_path -eq 0)  ]];then
		Fail_OpenMP
	else
		Pass_OpenMP "$l_file"
	fi
}

Fail_Flang_In_Path()
{
	gFailCount=$((gFailCount+1))
	gFailTestStatus="${gFailTestStatus}\t$gFailCount)WARNING: flang is not present in PATH\n\tWithout this compilation will fail for FORTRAN source code\n\tAdd bin folder of your AOCC compiler to PATH\n\n"
}

Fail_Flang1_In_Path()
{
        gFailCount=$((gFailCount+1))
        gFailTestStatus="${gFailTestStatus}\t$gFailCount)WARNING: flang1 is not present in PATH\n\tWithout this compilation will fail for FORTRAN source code\n\tAdd bin folder of your AOCC compiler to PATH\n\n"
}

Fail_Flang2_In_Path()
{
        gFailCount=$((gFailCount+1))
        gFailTestStatus="${gFailTestStatus}\t$gFailCount)WARNING: flang2 is not present in PATH\n\tWithout this compilation will fail for FORTRAN source code\n\tAdd bin folder of your AOCC compiler to PATH\n\n"
}

Pass_Flang_Test()
{
	gPassCount=$((gPassCount+1))
	tComp=$(dirname $gCompilerFlangUt )
	gPassTestStatus="${gPassTestStatus}\t$gPassCount) AOCC flang compiler bin => $tComp\n"
}

Test_Flang_In_Path()
{
	gCompilerFlangUt=$(which flang 2>/dev/null)
	if [[ ! (-e $gCompilerFlangUt) ]];then
		Fail_Flang_In_Path
	else
		 flng1=$(which flang1 2>/dev/null)
		 if [[ ! (-e $flng1) ]];then
                	Fail_Flang1_In_Path
		 else
			flng2=$(which flang2 2>/dev/null)
			if [[ ! (-e $flng2) ]];then
				Fail_Flang2_In_Path
			else
				Pass_Flang_Test
			fi
		 fi
	fi
}

Fail_Clang_In_Path()
{
	gFailCount=$((gFailCount+1))
	gFailTestStatus="${gFailTestStatus}\t$gFailCount)clang is not present in PATH\n\tWithout this compilation will fail for C source code\n\tAdd bin folder of your AOCC compiler to PATH\n\n"
}

Pass_ClangOrClang_Test()
{
	gPassCount=$((gPassCount+1))
	tComp=$(dirname $gCompilerUt)
	gPassTestStatus="${gPassTestStatus}\t$gPassCount) AOCC clang compiler bin => $tComp\n"
}

Test_Clang_In_Path()
{
	gCompilerUt=$(which clang 2>/dev/null)
	if [[ ! (-e $gCompilerUt) ]];then
		Fail_Clang_In_Path
	else
		Pass_ClangOrClang_Test
	fi
}

Fail_ClangPp_In_Path()
{
	gFailCount=$((gFailCount+1))
	gFailTestStatus="${gFailTestStatus}\t$gFailCount)clang++ is not present in PATH\n\tWithout this compilation will fail for C++ source code\n\tAdd bin folder of your AOCC compiler to PATH\n\n"
}

Pass_ClangOrClangPp_Test()
{
	gPassCount=$((gPassCount+1))
	tComp=$(dirname $gCompilerPpUt)
	gPassTestStatus="${gPassTestStatus}\t$gPassCount) AOCC clang++ compiler bin => $tComp\n"
}

Test_ClangPp_In_Path()
{
	gCompilerPpUt=$(which clang++ 2>/dev/null)
	if [[ ! (-e $gCompilerPpUt) ]];then
		Fail_ClangPp_In_Path
	else
		Pass_ClangOrClangPp_Test
	fi
}


Fail_libalm()
{
	gFailCount=$((gFailCount+1))
	gDynamicLibMissing=1
	gFailTestStatus="${gFailTestStatus}\t$gFailCount)WARNING:AMD LibM (libalm) is required in both LIBRARY_PATH and LD_LIBRARY_PATH\n\tMake sure that both LIBRARY_PATH and LD_LIBRARY_PATH have folder containing file ${glibalm[@]}\n\tYou can download AMD LibM from developer.amd.com \n\n"
}

Pass_libalm()
{
	gPassCount=$((gPassCount+1))
	gPassTestStatus="${gPassTestStatus}\t$gPassCount) AMD LibM (libalm) => $1\n"
}

Test_libalm()
{
local flagPass_LD_lib_path=0;
local flagPass_lib_path=0;

	ldPathAll=$LD_LIBRARY_PATH
	old_IFS=$IFS
	IFS=':';allFolders=$ldPathAll
	for folder in ${allFolders[@]};
	do
		if [[ -d "$folder" ]];then
		{
			for lib in ${glibalm[@]};
			do
				if [[ (-e "${folder}/${lib}") ]];then
					flagPass_LD_lib_path=1
					break 2
				fi
			done
		}
		fi
	done
	IFS=$old_IFS

	ldPathAll=$LIBRARY_PATH
	old_IFS=$IFS
	IFS=':';allFolders=$ldPathAll
	for folder in ${allFolders[@]};
	do
		if [[ -d "$folder" ]];then
		{
			for lib in ${glibalm[@]};
			do
				if [[ (-e "${folder}/${lib}") ]];then
					flagPass_lib_path=1
					break 2
				fi
			done
		}
		fi
	done
	IFS=$old_IFS

	if [[ ($flagPass_lib_path -eq 0) || ($flagPass_LD_lib_path -eq 0)  ]];then
		Fail_libalm
	else
		Pass_libalm "$folder"
	fi
}

Fail_Glibc_Version()
{
	gFailCount=$((gFailCount+1))
	gFailTestStatus="${gFailTestStatus}\t$gFailCount)Glibc version is less than ${gGlibcVersion}\n\tPlease upgrade to glibc version $gGlibcVersion or above\n\n"
}

Pass_Glibc_Version()
{
	gPassCount=$((gPassCount+1))
	gPassTestStatus="${gPassTestStatus}\t$gPassCount) Glibc version => $gCurrentGlibcVersion\n"
}

Test_Glibc_Version()
{
        glibcVersion=$(ldd --version)
	gCurrentGlibcVersion=$(echo $glibcVersion | awk -F' ' '{print $4}' | sed 's/(//g' | sed 's/)//g' )
        gCurrentGlibcVersion=$(echo $gCurrentGlibcVersion | sed 's/[ \t\n]//g')
	st=$(awk 'BEGIN{ print "'$gCurrentGlibcVersion'"<"'$gGlibcVersion'" }')
        if [[ $st -eq 1 ]]; then
          Fail_Glibc_Version
        else
          Pass_Glibc_Version
	fi
}

Fail_libtinfo()
{
errMsg="$1"
	gFailCount=$((gFailCount+1))
	gFailTestStatus="${gFailTestStatus}\t$gFailCount)Library $glibtinfo is missing\n\t${errMsg}\n\t\n\n"
}

Pass_libtinfo()
{
	gPassCount=$((gPassCount+1))
	gPassTestStatus="${gPassTestStatus}\t$gPassCount) $glibtinfoStr => $1\n"
}

Test_libtinfo()
{
ret1=0
ret2=0

        lib1=$(/sbin/ldconfig -p | grep "$glibtinfo" | grep 'x86-64')
        ret1=$?
        if [[ $ret1 -ne 0 ]]; then
		/sbin/ldconfig -p | grep "${glibtinfoStr}" | grep 'x86-64' &>/dev/null
		ret2=$?
        	if [[ $ret2 -eq 0 ]];then
        		otherVersion=$(/sbin/ldconfig -p | grep "${glibtinfoStr}" | head -n1 | grep 'x86-64' | awk -F'=>' '{print $2}')
        		dirLoc=$(dirname $otherVersion)
			if [[ -f $dirLoc/${glibtinfo} ]];then
				Pass_libtinfo "$lib1"
			else
	        		Fail_libtinfo "Other version of libtinfo is detected\n\tCreate softlink using command given below\n\tsudo ln -s $otherVersion $dirLoc/${glibtinfo}"
			fi
        	else
        		Fail_libtinfo "Install this library for AOCC compiler to work"
        	fi

        else
       		Pass_libtinfo "$lib1"
	fi
}

Fail_opt_viewer()
{
	gFailCount=$((gFailCount+1))
	gFailTestStatus="${gFailTestStatus}\t$gFailCount) In PATH opt-viewer is missing\n\t\n\n"
}

Pass_opt_viewer()
{
	gPassCount=$((gPassCount+1))
	gPassTestStatus="${gPassTestStatus}\t$gPassCount) In PATH opt-viewer is present\n"
}

Test_opt_viewer_In_Path()
{
 echo $PATH | grep -q "opt-viewer"
 ret_val=$?
 if [[ $ret_val -ne 0 ]]; then
	Fail_opt_viewer
 else
	Pass_opt_viewer
 fi
}

Fail_libz()
{
errMsg="$1"
	gFailCount=$((gFailCount+1))
	gFailTestStatus="${gFailTestStatus}\t$gFailCount)Library $glibz is missing\n\t${errMsg}\n\t\n\n"
}

Pass_libz()
{
	gPassCount=$((gPassCount+1))
	gPassTestStatus="${gPassTestStatus}\t$gPassCount) $glibzStr => $1\n"
}

Test_libz()
{
ret1=0
ret2=0

        lib1=$(/sbin/ldconfig -p | grep "$glibz" | grep 'x86-64')
        ret1=$?
        if [[ $ret1 -ne 0 ]]; then
		/sbin/ldconfig -p | grep "${glibzStr}" | grep 'x86-64' &>/dev/null
		ret2=$?
        	if [[ $ret2 -eq 0 ]];then
        		otherVersionLibz=$(/sbin/ldconfig -p | grep "${glibzStr}" | head -n1 | grep 'x86-64' | awk -F'=>' '{print $2}')
        		dirLoc=$(dirname $otherVersionLibz)
			if [[ -f $dirLoc/${glibz} ]];then
				Pass_libz "$lib1"
			else
	        		Fail_libz "Other version of libz is detected\n\tCreate softlink using command given below\n\tsudo ln -s $otherVersionLibz $dirLoc/${glibz}"
			fi
        	else
        		Fail_libz "Install this library for AOCC compiler to work"
        	fi

        else
       		Pass_libz "$lib1"
	fi
}

Fail_libstdcpp()
{
	gFailCount=$((gFailCount+1))
	gFailTestStatus="${gFailTestStatus}\t$gFailCount)Library libstdc++ is missing\n\tThis is required for C++ benchmarks\n\n"
}

Pass_libstdcpp()
{
	gPassCount=$((gPassCount+1))
	gPassTestStatus="${gPassTestStatus}\t$gPassCount) libstdc++ => $1\n"
}

Test_libstdcpp()
{
        lib1=$(/sbin/ldconfig -p | grep 'libstdc++.so' | grep 'libc6,x86-64')
        ret1=$?

        if [[ $ret1 -ne 0 ]]; then
		Fail_libstdcpp
        else
       		Pass_libstdcpp "$lib1"
	fi
}

Fail_libxml2()
{
        gFailCount=$((gFailCount+1))
        gFailTestStatus="${gFailTestStatus}\t$gFailCount)Library libxml2 is missing \n\n"
}

Pass_libxml2()
{
        gPassCount=$((gPassCount+1))
        gPassTestStatus="${gPassTestStatus}\t$gPassCount) libxml2 => $1\n"
}

Test_libxml2()
{
        lib1=$(/sbin/ldconfig -p | grep 'libxml2.so' | grep 'libc6,x86-64')
        ret1=$?

        if [[ $ret1 -ne 0 ]]; then
                Fail_libxml2
        else
                Pass_libxml2 "$lib1"
        fi
}

Fail_libquadmath()
{
        gFailCount=$((gFailCount+1))
        gFailTestStatus="${gFailTestStatus}\t$gFailCount)Library libquadmath is missing \n\n"
}

Pass_libquadmath()
{
        gPassCount=$((gPassCount+1))
        gPassTestStatus="${gPassTestStatus}\t$gPassCount) libquadmath => $1\n"
}

Test_libquadmath()
{
        lib1=$(/sbin/ldconfig -p | grep 'libquadmath.so.0' | grep 'libc6,x86-64')
        ret1=$?

        if [[ $ret1 -ne 0 ]]; then
                Fail_libquadmath
        else
                Pass_libquadmath "$lib1"
        fi
}


Fail_py_ver()
{
        gFailCount=$((gFailCount+1))
        gFailTestStatus="${gFailTestStatus}\t$gFailCount)WARNING: Python 3.5 or above is required for using OMPD, please refer to README for more details \n\n"
}

Pass_py_ver()
{
        gPassCount=$((gPassCount+1))
        gPassTestStatus="${gPassTestStatus}\t$gPassCount) Python 3.5 or above is present\n"
}

Test_py_ver()
{
       py_exe=$(which python3)
       if [[ -e $py_exe ]];then
		mv=$($py_exe --version | awk -F'.' '{print $2}')
		if [[ $mv -ge 5 ]];then
			Pass_py_ver
		else
			Fail_py_ver
		fi
       else
		Fail_py_ver
       fi
}


Usage()
{
	echo -e "\nThis script helps to check shell environment setting for AOCC usage"

        echo "Usage:"
        echo -e "\t $0 "
        echo -e "\t $0 -h for help\n"
}

gInput="$1"
if [[ ($1 == "-h") || ($1 == "--help")  ]];then
        Usage
else
	Test_Clang_In_Path
	Test_ClangPp_In_Path
	Test_Flang_In_Path
	Test_Glibc_Version
	Test_libstdcpp
	Test_libxml2
	Test_libquadmath
	Test_libalm
	Test_libtinfo
	Test_libz
	Test_OpenMP
	Test_crt_file
	Test_libc_and_m
	Test_py_ver
	Test_opt_viewer_In_Path
	printTestStatusAndExit
fi



